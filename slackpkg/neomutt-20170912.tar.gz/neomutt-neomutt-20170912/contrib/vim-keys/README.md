# Vim Keys

This Mutt config file sets up some keyboard mappings that make Mutt more
friendly for Vim users.  For example:

- gg  Move to top of Index
- G   Move to bottom of Index
- dd  Delete email from Index

## Credits

- Ivan Tham <pickfire@riseup.net>

