* **bug reports**

    * Expected behavior
    * Actual behavior
    * Steps to reproduce
    * Used program versions
    * Operating System and its version

* **feature requests**

    * Why do you not like the current state?
    * What would you like to see to change?
